var searchData=
[
  ['dificultad_0',['dificultad',['../struct_ahorcado.html#a72f0f14882e5e7b0e27c5c39108d1bbb',1,'Ahorcado']]],
  ['distribute_1',['distribute',['../license_8txt.html#aa3cf7f49d189d9fc5cee827d2633810d',1,'license.txt']]]
];

var searchData=
[
  ['copyright_0',['Copyright',['../license_8txt.html#adb8a6e7aacfe8ea9ef367b900957cb59',1,'license.txt']]]
];

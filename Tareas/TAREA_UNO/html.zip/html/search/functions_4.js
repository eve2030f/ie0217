var searchData=
[
  ['inicializajuego_0',['inicializaJuego',['../funciones_8cpp.html#ac32b32959d5a5f81f01bd7d270c5db30',1,'inicializaJuego(Ahorcado *juego, Dificultad dificultad, const std::vector&lt; std::string &gt; *diccionario):&#160;funciones.cpp'],['../funciones_8hpp.html#ac32b32959d5a5f81f01bd7d270c5db30',1,'inicializaJuego(Ahorcado *juego, Dificultad dificultad, const std::vector&lt; std::string &gt; *diccionario):&#160;funciones.cpp']]]
];

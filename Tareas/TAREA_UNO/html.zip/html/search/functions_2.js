var searchData=
[
  ['dificultadtostring_0',['dificultadToString',['../funciones_8cpp.html#adf91e3c958b6f89d27a9b5f65ebf31a0',1,'dificultadToString(Dificultad dificultad):&#160;funciones.cpp'],['../funciones_8hpp.html#adf91e3c958b6f89d27a9b5f65ebf31a0',1,'dificultadToString(Dificultad dificultad):&#160;funciones.cpp']]]
];

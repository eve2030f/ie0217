var searchData=
[
  ['merchantability_0',['MERCHANTABILITY',['../license_8txt.html#a8394add39a196c4852caa8c0e5450f37',1,'license.txt']]],
  ['merge_1',['merge',['../license_8txt.html#aad4b713ca657a67ecbb454b02ceabff8',1,'license.txt']]],
  ['modify_2',['modify',['../license_8txt.html#a84db115c842c0bc29f97fd73629d8163',1,'license.txt']]]
];

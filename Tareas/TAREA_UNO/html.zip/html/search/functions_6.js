var searchData=
[
  ['limpiarbufferentrada_0',['limpiarBufferEntrada',['../funciones_8cpp.html#aa8c2b4a4c8d6a22346e17a4b641aa3d4',1,'limpiarBufferEntrada():&#160;funciones.cpp'],['../funciones_8hpp.html#aa8c2b4a4c8d6a22346e17a4b641aa3d4',1,'limpiarBufferEntrada():&#160;funciones.cpp']]]
];

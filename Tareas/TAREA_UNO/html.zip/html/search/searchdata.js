var indexSectionsWithContent =
{
  0: "acdefijklmoprsu",
  1: "a",
  2: "aflm",
  3: "acdfijlm",
  4: "cdefiklmoprsu",
  5: "d",
  6: "dfi"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues"
};

var indexSectionLabels =
{
  0: "Todos",
  1: "Clases",
  2: "Archivos",
  3: "Funciones",
  4: "Variables",
  5: "Enumeraciones",
  6: "Valores de enumeraciones"
};


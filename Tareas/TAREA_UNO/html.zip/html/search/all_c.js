var searchData=
[
  ['restriction_0',['restriction',['../license_8txt.html#af6e42a41d4c1cf711ce91ba8a9536d5e',1,'license.txt']]]
];

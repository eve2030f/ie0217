var searchData=
[
  ['implied_0',['IMPLIED',['../license_8txt.html#a9c731e523f6a35737f231bf24431695d',1,'license.txt']]],
  ['intentos_1',['intentos',['../struct_ahorcado.html#a384d984100a057fb0cab95e64d317890',1,'Ahorcado']]],
  ['intentosmax_2',['intentosMax',['../struct_ahorcado.html#a76dd973da4c889d5247796152ca6889f',1,'Ahorcado']]],
  ['intentosrealizados_3',['intentosRealizados',['../struct_ahorcado.html#a947e48301a721474d659893daa7b94d7',1,'Ahorcado']]]
];

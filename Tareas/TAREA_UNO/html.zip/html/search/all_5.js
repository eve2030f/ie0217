var searchData=
[
  ['implied_0',['IMPLIED',['../license_8txt.html#a9c731e523f6a35737f231bf24431695d',1,'license.txt']]],
  ['inicializajuego_1',['inicializaJuego',['../funciones_8cpp.html#ac32b32959d5a5f81f01bd7d270c5db30',1,'inicializaJuego(Ahorcado *juego, Dificultad dificultad, const std::vector&lt; std::string &gt; *diccionario):&#160;funciones.cpp'],['../funciones_8hpp.html#ac32b32959d5a5f81f01bd7d270c5db30',1,'inicializaJuego(Ahorcado *juego, Dificultad dificultad, const std::vector&lt; std::string &gt; *diccionario):&#160;funciones.cpp']]],
  ['intentos_2',['intentos',['../struct_ahorcado.html#a384d984100a057fb0cab95e64d317890',1,'Ahorcado']]],
  ['intentosmax_3',['intentosMax',['../struct_ahorcado.html#a76dd973da4c889d5247796152ca6889f',1,'Ahorcado']]],
  ['intentosrealizados_4',['intentosRealizados',['../struct_ahorcado.html#a947e48301a721474d659893daa7b94d7',1,'Ahorcado']]],
  ['intermedio_5',['INTERMEDIO',['../ahorcado_8hpp.html#a27e53175e5a1bcdfaedde98f3f34efd8a77350155b646e5179da60a5f77117d03',1,'ahorcado.hpp']]]
];

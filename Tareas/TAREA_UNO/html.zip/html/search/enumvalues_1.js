var searchData=
[
  ['facil_0',['FACIL',['../ahorcado_8hpp.html#a27e53175e5a1bcdfaedde98f3f34efd8aebb947d4c4f47e15856d02d93a30c9b6',1,'ahorcado.hpp']]]
];

var searchData=
[
  ['so_0',['so',['../license_8txt.html#ad33c8f6a68363f2875b84f7c4ca98aba',1,'license.txt']]],
  ['software_1',['Software',['../license_8txt.html#acd5f6fc3bc0ca6669b69716abdd68f6a',1,'license.txt']]],
  ['sublicense_2',['sublicense',['../license_8txt.html#a9f571168d2ee9a598450704a59d048d3',1,'license.txt']]]
];

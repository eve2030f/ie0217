var searchData=
[
  ['kind_0',['KIND',['../license_8txt.html#a21bee792560027a3b96a9a882b5828d5',1,'license.txt']]]
];

var searchData=
[
  ['estadoactual_0',['estadoActual',['../struct_ahorcado.html#a6cdc91cdbd22f153b7c814853fd14a03',1,'Ahorcado']]]
];

var searchData=
[
  ['juegoterminado_0',['juegoTerminado',['../funciones_8cpp.html#ab2e71da3ba1cb44c571ea45b95ce8c60',1,'juegoTerminado(const Ahorcado *juego):&#160;funciones.cpp'],['../funciones_8hpp.html#ab2e71da3ba1cb44c571ea45b95ce8c60',1,'juegoTerminado(const Ahorcado *juego):&#160;funciones.cpp']]]
];

var searchData=
[
  ['dificultad_0',['Dificultad',['../ahorcado_8hpp.html#a27e53175e5a1bcdfaedde98f3f34efd8',1,'ahorcado.hpp']]]
];

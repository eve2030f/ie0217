var searchData=
[
  ['charge_0',['charge',['../license_8txt.html#af02105b8d25cac5346c70f0f8bebb2e8',1,'license.txt']]],
  ['claim_1',['CLAIM',['../license_8txt.html#a6f92969b6202008d5188110d8b5e0413',1,'license.txt']]],
  ['conditions_2',['conditions',['../license_8txt.html#a044015f5b936eb88da66708aa08bd4ac',1,'license.txt']]],
  ['contract_3',['CONTRACT',['../license_8txt.html#a0d659448dac5e185d9b9895b123b7735',1,'license.txt']]],
  ['copy_4',['copy',['../license_8txt.html#a5fc027ff17a37592346d4ce949961132',1,'license.txt']]]
];

var searchData=
[
  ['pais_0',['pais',['../class_pais.html#aa50e4c2c1ad6b2df64bfca31d8874c44',1,'Pais']]],
  ['pib_1',['pib',['../class_pais.html#ad1d1f95c472c234480e735d5184de52b',1,'Pais']]]
];

var searchData=
[
  ['pais_0',['Pais',['../class_pais.html',1,'']]],
  ['planeta_1',['Planeta',['../class_planeta.html',1,'']]],
  ['primermundo_2',['PrimerMundo',['../class_primer_mundo.html',1,'']]]
];

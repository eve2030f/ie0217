var searchData=
[
  ['_7epais_0',['~Pais',['../class_pais.html#a004df1065d2223533d7b1189211fc564',1,'Pais']]],
  ['_7eplaneta_1',['~Planeta',['../class_planeta.html#a993da028bdf10b6089f1b75c43184b2b',1,'Planeta']]]
];

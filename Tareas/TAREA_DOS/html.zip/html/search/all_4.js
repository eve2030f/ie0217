var searchData=
[
  ['eliminarpais_0',['eliminarPais',['../class_pais.html#a13340e509f25266af88e9cf85d5e9e13',1,'Pais']]],
  ['esprimo_1',['esPrimo',['../funciones_8cpp.html#a8a4484ed6034668b29d5dfbf16fd61ce',1,'funciones.cpp']]]
];

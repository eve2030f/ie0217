var searchData=
[
  ['id_5fdesarrollo_0',['id_desarrollo',['../class_pais.html#ad02d3cc70a076f21278a1f3dc31e1030',1,'Pais']]],
  ['id_5fprimo_1',['id_primo',['../class_pais.html#af017ae317ba77707fa9dfafb0bb4b856',1,'Pais']]]
];

var searchData=
[
  ['pais_0',['Pais',['../class_pais.html#ad7c1cc6eae7e93eab7d53add231b656c',1,'Pais']]],
  ['planeta_1',['Planeta',['../class_planeta.html#a10c7cce0f66a3d7ab4fa309dab665724',1,'Planeta']]],
  ['primermundo_2',['PrimerMundo',['../class_primer_mundo.html#a0475ab9eb1251aca596bacff417c1550',1,'PrimerMundo']]]
];

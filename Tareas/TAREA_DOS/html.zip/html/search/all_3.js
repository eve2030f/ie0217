var searchData=
[
  ['de_20doxyfile_20por_20medio_20del_20netlify_20haga_20click_20a_3a_0',['Link de Doxyfile por medio del Netlify haga click a:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['del_20netlify_20haga_20click_20a_3a_1',['Link de Doxyfile por medio del Netlify haga click a:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['desarrollo_2',['Desarrollo',['../class_desarrollo.html',1,'Desarrollo'],['../class_desarrollo.html#ad470e6b31793e27d1adb219655032a76',1,'Desarrollo::Desarrollo()']]],
  ['doxyfile_20por_20medio_20del_20netlify_20haga_20click_20a_3a_3',['Link de Doxyfile por medio del Netlify haga click a:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]]
];

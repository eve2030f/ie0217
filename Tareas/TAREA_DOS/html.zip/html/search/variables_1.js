var searchData=
[
  ['cincog_0',['cincog',['../class_pais.html#afe1fe0e1d64eeef9574d96ffbbe859a3',1,'Pais']]],
  ['continente_1',['continente',['../class_pais.html#a9438dd1408fe0f4215f420a276b1931c',1,'Pais']]]
];

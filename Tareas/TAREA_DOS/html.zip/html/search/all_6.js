var searchData=
[
  ['generarid_0',['generarid',['../class_pais.html#ad88e4db5ff72d732b426a1faf3607435',1,'Pais::generarid()'],['../class_desarrollo.html#a568082a1e20a9ddae6d01148be1e0791',1,'Desarrollo::generarid()'],['../class_primer_mundo.html#a52b5921567f1642cf19133f990e0bc93',1,'PrimerMundo::generarid()']]]
];

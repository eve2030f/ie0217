var searchData=
[
  ['2_0',['Tarea 2',['../md__r_e_a_d_m_e.html',1,'']]]
];

var searchData=
[
  ['tarea_202_0',['Tarea 2',['../md__r_e_a_d_m_e.html',1,'']]],
  ['teórica_1',['Parte Teórica',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]]
];
